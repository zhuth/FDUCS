#include <cstdio>
#include <cstdlib>
#include <cstring>
#define LOOP(x) for(int x=1;x<=6;++x)
int main() {
char* buf = "The future will be better tomorrow.\n1 2 6 24 120 720\n1 -678\n11\n- -%+!\n";
LOOP(a) LOOP(b) LOOP(c) LOOP(d) LOOP(e) LOOP(f) {
	//if (a==b||a==c||a==d||a==e||a==f||b==c||b==d||b==e||b==f||c==d||c==e||c==f||d==e||d==f||e==f) continue;
	FILE* file = fopen("tmp", "w");
	fprintf(file, "%s%d %d %d %d %d %d", buf, a, b, c, d, e, f);
	printf("%d %d %d %d %d %d\n", a, b, c, d, e, f);
	fclose(file);
	system("./bomb tmp | grep BOOM");
	for(int i=0; i<10000000; ++i);
}
}
